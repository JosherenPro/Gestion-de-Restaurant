# ?? Guide de Test Complet - Frontend ? Backend

## ?? �tape 1 : D�marrer le Backend

**Terminal 1 (PowerShell) :**
```powershell
cd backend
python -m uvicorn app.main:app --reload
```

**? V�rification :**
- Ouvrir http://localhost:8000/docs
- Vous devriez voir la documentation Swagger

---

## ?? �tape 2 : D�marrer le Frontend

**Terminal 2 (PowerShell) :**
```powershell
cd Frontend
npm install
npm run dev
```

**? V�rification :**
- Ouvrir http://localhost:3000
- L'application s'affiche

---

## ?? �tape 3 : Activer la Vue Connect�e

**Modifier `Frontend/App.tsx` ligne 3 :**
```typescript
// AVANT
import { ClientView } from './components/ClientView';

// APR�S
import { ClientView } from './components/ClientViewConnected';
```

**Sauvegarder et recharger la page (F5)**

---

## ?? �tape 4 : Cr�er des Donn�es de Test

**Aller sur http://localhost:8000/docs**

### 1. Cr�er une Cat�gorie
- Trouver `POST /categories/`
- Cliquer **"Try it out"**
- Copier-coller :
```json
{
  "nom": "Burgers",
  "description": "Nos d�licieux burgers"
}
```
- Cliquer **"Execute"**
- ? Vous devriez avoir un code **200** avec `"id": 1`

### 2. Cr�er un Plat
- Trouver `POST /plats/`
- Cliquer **"Try it out"**
- Copier-coller :
```json
{
  "nom": "Burger Classic",
  "description": "Un d�licieux burger avec salade, tomate, cornichons",
  "prix": 1200,
  "categorie_id": 1,
  "disponible": true,
  "temps_preparation": 15
}
```
- Cliquer **"Execute"**
- ? Code **200** avec `"id": 1`

### 3. Cr�er une Deuxi�me Cat�gorie
```json
{
  "nom": "Pizzas",
  "description": "Nos pizzas maison"
}
```

### 4. Cr�er un Deuxi�me Plat
```json
{
  "nom": "Pizza Margherita",
  "description": "Sauce tomate, mozzarella, basilic",
  "prix": 1100,
  "categorie_id": 2,
  "disponible": true,
  "temps_preparation": 20
}
```

### 5. Cr�er une Table
- Trouver `POST /tables/`
- Cliquer **"Try it out"**
- Copier-coller :
```json
{
  "numero_table": "T1",
  "capacite": 4,
  "statut": "LIBRE",
  "qr_code": "QR-T1"
}
```
- Cliquer **"Execute"**

---

## ?? �tape 5 : Tester l'Application

### Test 1 : Voir le Menu
1. Aller sur http://localhost:3000
2. Cliquer sur **"Commander maintenant"**
3. ? Vous devriez voir vos 2 plats
4. ? Vous devriez voir les 2 cat�gories (Burgers, Pizzas)

### Test 2 : Passer une Commande
1. Cliquer sur le **+** � c�t� d'un plat
2. L'ic�ne panier en haut affiche **1**
3. Cliquer sur l'**ic�ne panier**
4. Voir le plat dans le panier
5. Cliquer sur **"Commander maintenant"**
6. ? Vous voyez "Commande en cours" avec le statut

### Test 3 : V�rifier dans la Base
1. Retourner sur http://localhost:8000/docs
2. Trouver `GET /commandes/`
3. Cliquer **"Try it out"** puis **"Execute"**
4. ? Vous devriez voir votre commande dans la r�ponse

---

## ?? Tests dans la Console du Navigateur

**Ouvrir la console (F12) et taper :**

### Test API directe
```javascript
fetch('http://localhost:8000/categories/')
  .then(res => res.json())
  .then(data => console.log('? Cat�gories:', data))
```

### Test des Plats
```javascript
fetch('http://localhost:8000/plats/')
  .then(res => res.json())
  .then(data => console.log('? Plats:', data))
```

---

## ?? Checklist Finale

- [ ] Backend d�marre sans erreur
- [ ] Frontend d�marre sans erreur
- [ ] Swagger accessible (http://localhost:8000/docs)
- [ ] Au moins 1 cat�gorie cr��e
- [ ] Au moins 1 plat cr��
- [ ] Au moins 1 table cr��e
- [ ] Le menu s'affiche dans l'interface
- [ ] Peut ajouter un plat au panier
- [ ] Peut cr�er une commande
- [ ] La commande appara�t dans `GET /commandes/`

---

## ?? R�solution de Probl�mes

### ? CORS Error
**Solution :** V�rifier `backend/app/main.py` contient :
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### ? Failed to Fetch
**Solution :** V�rifier `Frontend/.env` :
```
VITE_API_URL=http://localhost:8000
```
Puis red�marrer le frontend.

### ? "Aucun plat trouv�"
**Solution :** Cr�er des donn�es via l'�tape 4.

### ? 500 Internal Server Error
**Solution :** Regarder les logs du backend dans le terminal.

---

## ?? Script Rapide (Optionnel)

**Pour cr�er toutes les donn�es en une fois :**

Dans le terminal du backend :
```python
python -c "
from app.core.database import engine
from sqlmodel import Session
from app.models.categorie import Categorie
from app.models.plat import Plat
from app.models.table import Table

with Session(engine) as session:
    # Cat�gories
    cat1 = Categorie(nom='Burgers', description='Nos burgers')
    cat2 = Categorie(nom='Pizzas', description='Nos pizzas')
    session.add_all([cat1, cat2])
    session.commit()
    session.refresh(cat1)
    session.refresh(cat2)
    
    # Plats
    plat1 = Plat(nom='Burger Classic', description='D�licieux', prix=1200, categorie_id=cat1.id, disponible=True)
    plat2 = Plat(nom='Pizza Margherita', description='Tomate, mozzarella', prix=1100, categorie_id=cat2.id, disponible=True)
    session.add_all([plat1, plat2])
    
    # Table
    table = Table(numero_table='T1', capacite=4, statut='LIBRE', qr_code='QR-T1')
    session.add(table)
    
    session.commit()
    print('? Donn�es cr��es !')
"
```

---

## ?? R�sultats Attendus

### Dans le Backend (Terminal 1)
```
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete.
INFO:     127.0.0.1:xxxxx - "GET /plats/ HTTP/1.1" 200 OK
INFO:     127.0.0.1:xxxxx - "POST /commandes/ HTTP/1.1" 200 OK
```

### Dans le Frontend (Terminal 2)
```
VITE v6.2.0  ready in 500 ms
?  Local:   http://localhost:3000/
```

### Dans l'Interface
- Menu avec cat�gories "Burgers" et "Pizzas"
- Plats affich�s avec prix et description
- Panier fonctionnel
- Commande cr��e avec succ�s

---

**? Si tous les tests passent, votre int�gration fonctionne parfaitement ! ??**

/**
 * Export centralis� de tous les composants du syst�me
 * Facilite les imports dans d'autres fichiers
 */

// Vues principales par r�le
export { ClientView } from './ClientViewConnected';
export { ServerViewConnected } from './ServerViewConnected';
export { CuisinierViewConnected } from './CuisinierViewConnected';
export { GerantViewConnected } from './GerantViewConnected';

// Vues sp�cialis�es
export { ReservationManagerView } from './ReservationManagerView';
export { LoginView } from './LoginView';

// Router et utilitaires
export { RoleBasedRouter, ROLE_ROUTES, useCurrentRoute } from './RoleBasedRouter';

// Composants UI
export { Card, Button, Modal, Badge } from './UI';

/**
 * Guide d'utilisation rapide:
 * 
 * 1. Pour une application simple avec routing automatique:
 *    import { RoleBasedRouter } from './components';
 *    <RoleBasedRouter />
 * 
 * 2. Pour afficher une vue sp�cifique:
 *    import { GerantViewConnected } from './components';
 *    <GerantViewConnected />
 * 
 * 3. Pour cr�er une navigation personnalis�e:
 *    import { ROLE_ROUTES } from './components';
 *    const routes = Object.values(ROLE_ROUTES);
 */

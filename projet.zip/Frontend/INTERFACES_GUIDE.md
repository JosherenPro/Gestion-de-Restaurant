# ??? Syst�me de Gestion de Restaurant - Guide des Interfaces

## ?? Vue d'ensemble

Ce syst�me propose **4 interfaces distinctes** selon le r�le de l'utilisateur, chacune adapt�e � ses besoins sp�cifiques.

---

## ?? Interfaces par R�le

### 1. ????? **Interface Cuisinier**
**Fichier:** `CuisinierViewConnected.tsx`

#### Fonctionnalit�s:
- ? **Consulter les commandes en cours** (temps r�el)
- ? **Prendre en charge une commande** (passer de "En attente" � "En cours")
- ? **Marquer comme pr�t** (notifier le serveur)
- ? **Gestion du stock** - D�clarer des plats indisponibles/disponibles
- ? Rafra�chissement automatique toutes les 20 secondes

#### Onglets:
1. **Commandes** - Workflow cuisine (� pr�parer ? En cuisson)
2. **Gestion Stock** - Disponibilit� des plats

---

### 2. ?? **Interface Serveur**
**Fichier:** `ServerViewConnected.tsx`

#### Fonctionnalit�s:
- ? **Consulter la liste des tables** avec statut (libre/occup�e/r�serv�e)
- ? **Affecter/Lib�rer/Modifier une table**
- ? **Prendre une commande** manuellement (pour clients sans app)
- ? **Transmettre la commande en cuisine**
- ? **Consulter le statut des commandes**
- ? **Valider les commandes** en attente
- ? **Marquer comme servi** les plats pr�ts

#### Interface:
- **Sidebar** - Plan de salle interactif
- **Main** - Liste des commandes actives
- **Modal** - Prise de commande avec panier

---

### 3. ?? **Interface G�rant**
**Fichier:** `GerantViewConnected.tsx`

#### Fonctionnalit�s principales:

##### ?? **Dashboard (Tableau de bord)**
- Chiffre d'affaires total
- Nombre de commandes
- Nombre de clients
- Note moyenne
- Top 5 des plats les plus vendus

##### ?? **Gestion du Menu**
- Ajouter/Modifier/Supprimer des plats
- G�rer les prix (en centimes)
- Upload d'images de plats
- Disponibilit� des plats

##### ????? **Gestion du Personnel**
- Ajouter/Modifier/Supprimer du personnel
- G�rer les r�les (G�rant/Serveur/Cuisinier)
- Consulter les informations (email, t�l�phone)

##### ?? **Gestion des Tables**
- Ajouter/Modifier/Supprimer des tables
- G�rer la capacit�
- Statut en temps r�el (libre/occup�e/r�serv�e)
- Codes QR pour acc�s client

##### ?? **Gestion des R�servations**
- Interface compl�te `ReservationManagerView`
- Confirmer ou refuser les r�servations
- Voir les d�tails (client, date, nombre de personnes, notes)
- Statistiques (en attente, confirm�es, annul�es)

##### ?? **Statistiques**
- Rapports de ventes
- Popularit� des plats
- Analyses d�taill�es

#### Navigation par onglets:
```
Dashboard | Menu | Tables | Personnel | R�servations | Statistiques
```

---

### 4. ?? **Interface Client**
**Fichier:** `ClientViewConnected.tsx`

#### Fonctionnalit�s:
- ? Consulter le menu par cat�gories
- ? Commander des plats
- ? Suivre la commande en temps r�el
- ? **Faire une r�servation** (avec date, heure, nombre de personnes, notes)
- ? Laisser un avis

---

## ?? Syst�me de Routage Automatique

Le fichier `RoleBasedRouter.tsx` g�re automatiquement l'affichage de la bonne interface selon le r�le de l'utilisateur connect�.

### Utilisation dans App.tsx:
```typescript
import { RoleBasedRouter } from './components/RoleBasedRouter';
import { AuthProvider } from './context/AuthContext';

const App = () => (
  <AuthProvider>
    <RoleBasedRouter />
  </AuthProvider>
);
```

### Flux d'authentification:
```
Non connect� ? LoginView
     ?
 Connexion
     ?
CLIENT ? ClientView
SERVEUR ? ServerViewConnected
CUISINIER ? CuisinierViewConnected
GERANT ? GerantViewConnected
```

---

## ?? Comptes de test

```typescript
// G�rant
Email: gerant@resto.com
Mot de passe: password123

// Serveur
Email: serveur@resto.com
Mot de passe: password123

// Cuisinier
Email: cuisinier@resto.com
Mot de passe: password123
```

---

## ?? Int�gration avec l'API

Toutes les interfaces sont **enti�rement connect�es** � l'API backend via `apiService`:

### Exemples d'appels:
```typescript
// Commandes
await apiService.getCommandes();
await apiService.validerCommande(id, serveurId, token);
await apiService.preparerCommande(id, token);
await apiService.commandePrete(id, cuisinierId, token);

// R�servations
await apiService.getReservations();
await apiService.confirmerReservation(id, token);
await apiService.annulerReservation(id, token);

// Stats (G�rant uniquement)
await apiService.getStatsGlobal(token);
await apiService.getTopPlats(token);
```

---

## ?? Design System

### Couleurs principales:
- **Primary Orange:** `#FC8A06`
- **Dark Blue:** `#03081F`
- **Success Green:** `#10B981`
- **Warning Orange:** `#F59E0B`

### Composants UI r�utilisables:
- `Card` - Cartes avec ombres et bordures arrondies
- `Button` - Variantes (primary, secondary, outline, success)
- `Modal` - Fen�tres modales responsives
- `Badge` - Badges de statut color�s

---

## ?? Lancement

### D�veloppement:
```bash
cd Frontend
npm install
npm run dev
```

### Production:
```bash
npm run build
npm run preview
```

---

## ?? Structure des fichiers

```
Frontend/
??? components/
?   ??? ClientViewConnected.tsx        # Interface client
?   ??? ServerViewConnected.tsx        # Interface serveur
?   ??? CuisinierViewConnected.tsx     # Interface cuisinier
?   ??? GerantViewConnected.tsx        # Interface g�rant
?   ??? ReservationManagerView.tsx     # Gestion r�servations
?   ??? LoginView.tsx                  # Authentification
?   ??? RoleBasedRouter.tsx            # Routage automatique
?   ??? UI.tsx                         # Composants UI
?   ??? index.ts                       # Export centralis�
??? services/
?   ??? api.service.ts                 # Appels API
??? context/
?   ??? AuthContext.tsx                # Gestion auth
??? types.ts                           # Types TypeScript
??? App.tsx                            # Point d'entr�e

```

---

## ? Checklist des fonctionnalit�s

### Serveur ?
- [x] Consulter la liste des tables
- [x] Affecter/Lib�rer/Modifier une table
- [x] Prendre une commande (enregistrer sans app)
- [x] Transmettre la commande en cuisine
- [x] Consulter le statut des commandes

### Cuisinier ?
- [x] Consulter les commandes en cours
- [x] Prendre en charge et pr�parer
- [x] Marquer comme pr�t

### G�rant ?
- [x] G�rer le menu (ajouter/modifier/supprimer plats)
- [x] G�rer les prix
- [x] G�rer le personnel (ajouter/modifier/supprimer)
- [x] G�rer les tables
- [x] Consulter les statistiques
- [x] G�n�rer des rapports (ventes, popularit�)
- [x] G�rer les stocks (via cuisinier)
- [x] **G�rer les r�servations** (confirmer/refuser)

### Client ?
- [x] Consulter le menu
- [x] Commander
- [x] Suivre la commande
- [x] Faire une r�servation
- [x] Laisser un avis

---

## ?? Personnalisation

Pour adapter le syst�me � vos besoins:

1. **Modifier les couleurs** ? `tailwind.config.js`
2. **Ajouter des statistiques** ? `GerantViewConnected.tsx`
3. **Personnaliser le workflow** ? Modifier les �tats dans `types.ts`
4. **Ajouter des fonctionnalit�s** ? �tendre `api.service.ts`

---

## ?? Support

Pour toute question ou am�lioration, consultez la documentation du backend ou cr�ez une issue sur GitHub.

---

**D�velopp� avec ?? pour une exp�rience restaurant moderne et compl�te**

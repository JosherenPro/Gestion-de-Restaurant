<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# RestoManager Pro - Frontend

Application de gestion de restaurant compl�te avec interface React connect�e � un backend FastAPI.

## ?? D�marrage Rapide

### Pr�requis

- Node.js (v16 ou sup�rieur)
- Backend FastAPI en cours d'ex�cution (voir `../backend/README.md`)

### Installation

1. Installer les d�pendances :
   ```bash
   npm install
   ```

2. Configurer les variables d'environnement :
   ```bash
   cp .env.example .env
   ```
   
   �ditez `.env` et configurez l'URL du backend :
   ```env
   VITE_API_URL=http://localhost:8000
   ```

3. D�marrer l'application :
   ```bash
   npm run dev
   ```

L'application sera accessible sur `http://localhost:3000`

## ?? Fonctionnalit�s

### Vue Client ??
- Navigation dans le menu par cat�gories
- Recherche de plats
- Panier de commande
- Suivi de commande en temps r�el
- R�servation de tables
- Syst�me d'avis

### Vue Serveur ???
- Gestion des tables
- Validation des commandes
- Service des plats
- Gestion des r�servations

### Vue Cuisinier ?????
- Affichage des commandes en attente
- Pr�paration des plats
- Marquage des commandes pr�tes

### Vue G�rant ??
- Tableau de bord avec statistiques
- Gestion du menu et des plats
- Gestion du personnel
- Chiffre d'affaires et indicateurs
- Top des plats vendus

## ??? Structure du Projet

```
Frontend/
??? components/          # Composants React
?   ??? ClientView.tsx          # Vue client (mock)
?   ??? ClientViewConnected.tsx # Vue client connect�e au backend
?   ??? ServerView.tsx          # Vue serveur
?   ??? ChefView.tsx            # Vue cuisinier
?   ??? AdminView.tsx           # Vue g�rant
?   ??? UI.tsx                  # Composants UI r�utilisables
??? config/              # Configuration
?   ??? api.config.ts           # Configuration des endpoints API
??? context/             # Contextes React
?   ??? AuthContext.tsx         # Gestion de l'authentification
??? hooks/               # Hooks personnalis�s
?   ??? useApi.ts               # Hooks pour les appels API
??? services/            # Services
?   ??? api.service.ts          # Service API
??? App.tsx              # Composant principal
??? types.ts             # Types TypeScript
??? mockData.ts          # Donn�es de d�monstration
??? BACKEND_INTEGRATION.md # Guide d'int�gration avec le backend
```

## ?? Int�gration Backend

Le frontend est con�u pour se connecter au backend FastAPI. Consultez [BACKEND_INTEGRATION.md](./BACKEND_INTEGRATION.md) pour :

- Configuration de l'API
- Utilisation des hooks et services
- Authentification et gestion des tokens
- Correspondance des types de donn�es
- Exemples de code

### Endpoints API Principaux

- **Auth** : `/auth/token`, `/auth/verify`
- **Menu** : `/categories`, `/plats`
- **Commandes** : `/commandes`, `/commandes/{id}/lignes`
- **Tables** : `/tables`, `/tables/qr/{qr_code}`
- **R�servations** : `/reservations`
- **Stats** : `/stats/global`, `/stats/dashboard`

## ?? Technologies

- **React 19** - Framework UI
- **TypeScript** - Typage statique
- **Vite** - Build tool
- **Lucide React** - Ic�nes
- **Recharts** - Graphiques (stats)
- **Tailwind CSS** - Styling (via classes utilitaires)

## ?? Authentification

L'application utilise JWT tokens pour l'authentification :

```typescript
import { useAuth } from './context/AuthContext';

const { login, logout, user, isAuthenticated } = useAuth();

// Connexion
await login('email@example.com', 'password');

// V�rifier l'�tat
if (isAuthenticated) {
  console.log('Utilisateur:', user);
}

// D�connexion
logout();
```

## ?? Mode D�monstration

Pour tester l'application sans backend, utilisez les composants originaux qui utilisent des donn�es mock :

- `ClientView.tsx` utilise `mockData.ts`
- Passez entre les diff�rentes vues avec le s�lecteur de r�le

Pour utiliser le backend r�el :

- Remplacez l'import dans `App.tsx` :
  ```typescript
  // import { ClientView } from './components/ClientView';
  import { ClientView } from './components/ClientViewConnected';
  ```

## ?? Responsive Design

L'application est optimis�e pour :
- ?? Mobile (vue client)
- ?? Desktop (vues serveur, cuisinier, g�rant)
- ??? Tablette

## ??? Scripts Disponibles

```bash
# D�veloppement
npm run dev

# Build production
npm run build

# Pr�visualisation du build
npm run preview
```

## ?? D�bogage

### Probl�mes de connexion au backend

1. V�rifiez que le backend est d�marr� :
   ```bash
   curl http://localhost:8000/categories/
   ```

2. V�rifiez la configuration CORS dans le backend

3. Consultez la console du navigateur pour les erreurs

### Erreurs communes

- **CORS Error** : Le backend doit autoriser `http://localhost:3000`
- **401 Unauthorized** : Token expir�, reconnectez-vous
- **404 Not Found** : Backend non d�marr� ou mauvaise URL dans `.env`

## ?? Documentation

- [Guide d'int�gration Backend](./BACKEND_INTEGRATION.md)
- [Documentation API Backend](../backend/docs/frontend/API_GUIDE.md)
- [Formats de donn�es](../backend/docs/frontend/DATA_FORMATS.md)

## ?? Contribution

1. Cr�ez une branche pour votre fonctionnalit�
2. Committez vos changements
3. Cr�ez une Pull Request

## ?? Licence

Ce projet est open source.

## ?? Liens Utiles

- **API Documentation** : http://localhost:8000/docs
- **AI Studio** : https://ai.studio/apps/temp/1

